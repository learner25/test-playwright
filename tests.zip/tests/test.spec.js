 const sidebarElement = page.locator('//*[@id="asana_sidebar"]/div[1]/div/div[1]/div[1]/div[2]/div/div[2]/nav/div[2]/div/div[1]/a/span');
        await sidebarElement.click();
        console.log("Sidebar element clicked successfully.");

        // Wait for the board cards to load
        await page.waitForTimeout(7000);

        //*[@id="asana_sidebar"]/div[1]/div/div[1]/div[1]/div[2]/div/div[2]/nav/div[2]/div/div[2]/a