const { test, expect } = require('@playwright/test');
const fs = require('fs');
test.beforeAll(() => {
    const rawData = fs.readFileSync('tests/testData.json'); // Replace with the actual JSON file path
    let testData = JSON.parse(rawData);
    console.log(testData)
});

test.describe('Asana Login Tests-2', () => {
    test.beforeEach(async ({ page }) => {

        await page.goto('https://app.asana.com/-/login');
        await page.fill('input[name="e"]', 'ben+pose@workwithloop.com');
        page.getByRole('button', { name: 'Continue', exact: true }).click();
        await page.waitForTimeout(5000);
        await page.fill('input[name="p"]', 'Password123');
        page.getByRole('button', { name: 'Log in', exact: true }).click();
        await page.waitForURL('**/home/**');
    });
    test.afterEach(async ({ page }) => {
        // Validate the page URL and title
        await expect(page.url()).toMatch(/https:\/\/app\.asana\.com\/0\/home\/\d+/);
        await expect(page).toHaveTitle(/Home - Asana/);

        // Wait for the board columns to load
        await page.waitForTimeout(1000);

        const sidebarElement = page.locator('//*[@id="asana_sidebar"]/div[1]/div/div[1]/div[1]/div[2]/div/div[2]/nav/div[2]/div/div[2]/a/span');
        await sidebarElement.click();
        console.log("Sidebar element clicked successfully.");

        // Wait for the board cards to load
        await page.waitForTimeout(7000);
        // Locate the "To-Do" column
        const todoColumn = page.locator('.CommentOnlyBoardColumn', { hasText: "New Requests" });
        await expect(todoColumn).toHaveCount(1); // Verify that exactly one "To-Do" column is present

        console.log("Located the 'New Requests' column successfully.");

        // Locate all board cards under the "To-Do" column
        const boardCards = todoColumn.locator('.BoardCard-layout');
        const cardCount = await boardCards.count();
        console.log(`Total cards found in 'To-Do' column: ${cardCount}`);

        // Texts to verify in board cards
        const requiredTexts = ["[Example] Laptop setup for new hire", "[Example] Password not working", "[Example] New keycard for Daniela V"];
        const nestedTexts = ["Low effort", "High Priority","Medium Priority","Low priority", "Password reset", "Waiting", "New Hardware", "Done","Not Started"];

        // Iterate through each board card in the "To-Do" column
        for (let i = 0; i < cardCount; i++) {
            const card = boardCards.nth(i);
            const cardText = await card.textContent();

            // Check if the card contains any of the required texts
            const matches = requiredTexts.filter(text => cardText.includes(text));
            if (matches.length > 0) {
                console.log(`Card ${i + 1} matches: ${matches.join(", ")}`);

                // Verify nested elements
                const pill = card.locator('.PillThemeablePresentation');
                for (const nestedText of nestedTexts) {
                    const count = await pill.filter({ hasText: nestedText }).count();
                    if (count > 0) {
                        console.log(`Card ${i + 1} contains nested text: "${nestedText}".`);
                    } else {
                        console.log(`Card ${i + 1} does NOT contain nested text: "${nestedText}".`);
                    }
                }
            } else {
                console.log(`Card ${i + 1} does not match required texts.`);
            }
        }

        // Debugging placeholder
        console.log("Verification completed.");
        await new Promise(() => { });
    });




    test('Navigate and verify project task details', async ({ page }) => {
        // Example: navigate and verify tasks
    });
});
////*[@id="asana_main_page"]/div[1]/div[1]/div[2]/div/span[2]